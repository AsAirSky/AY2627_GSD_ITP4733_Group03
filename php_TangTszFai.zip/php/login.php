<?PHP
		$dbuser = 'root';
		$dbhost = 'localhost';
		$dbpass = ''; //type your password here
		$db = 'TangTszFai'; //type your password here

		$username = "Kimura Takuya";		//for web testing
		$password = "123456";

		$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db);
		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
		
		$query = "select password from users where username ='".$username."'";
		$result = mysqli_query($conn, $query);
		
              //get result and login
		if (mysqli_num_rows($result) > 0 ) {    
			while ($row = mysqli_fetch_assoc($result)) { //array	
				if($row['password'] == $password) {
				  echo "login success";
				  echo $row['password'];
				} else{
				  echo "password inccorrect";
				  echo "password is = ".$row['password'];
				}					
			}//while
		}	else {
				die("user not found!");
		}			
		mysqli_close($conn);
?>
