<?PHP
	$dbuser = 'root';
	$dbhost = 'localhost';
	$dbpass = ''; //type your password here
	$db = 'TangTszFai'; //type your password here
		
	$username = $_POST["usernamePost"]; 
	$email = $_POST["emailPost"];
	$password = $_POST["passwordPost"];

	//make connection
	$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db);
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
		
		
	$query = "INSERT INTO users (username, email,password) values
                 ('".$username."','".$email."','".$password."')";//sql
	$result = mysqli_query($conn, $query);
		
    //echo $query;
    if(!$result)  echo "there was an error";
    else echo "everything ok."
?>
