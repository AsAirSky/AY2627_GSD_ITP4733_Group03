<?PHP
		$dbuser = 'root';
		$dbhost = 'localhost';
		$dbpass = ''; //type your password here
		$db = 'TangTszFai'; //type your password here
		
		$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db);
		if (!$conn) {
				 die("Connection failed: " . mysqli_connect_error());
		}
	
		$query = 'select * from Items';	//sql
		$result = mysqli_query($conn, $query);
		
		if ($result) {
			while ($row = mysqli_fetch_assoc($result))
			{ 
                                          echo "ID:".$row["ID"]."|Name:".$row["Name"].
                                                   "|Type:".$row["Type"]."|Cost:".$row["Cost"].";";
			}					
		}	else {
				die("Error selecting records: " . mysqli_error($conn));
		}			
		mysqli_close($conn);
?>

